package com.citycare.citizenservice.controller;

import com.citycare.citizenservice.dto.ApiResponse;
import com.citycare.citizenservice.dto.CitizenProfileRequest;
import com.citycare.citizenservice.entity.Citizen;
import com.citycare.citizenservice.entity.CitizenDocument;
import com.citycare.citizenservice.service.CitizenService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/citizens")
@RequiredArgsConstructor
@Tag(name = "Citizen", description = "Citizen profiles and documents")
public class CitizenController {

    private final CitizenService citizenService;

    @PutMapping("/profile")
    @Operation(summary = "[CITIZEN/ADMIN] Create or update citizen profile")
    public ResponseEntity<ApiResponse<Citizen>> upsertProfile(
            @Valid @RequestBody CitizenProfileRequest request,
            @RequestHeader("X-Auth-UserId") Long userId) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Profile saved", citizenService.createOrUpdateProfile(userId, request)));
    }

    @GetMapping("/profile")
    @Operation(summary = "[CITIZEN] Get my profile")
    public ResponseEntity<ApiResponse<Citizen>> getMyProfile(
            @RequestHeader("X-Auth-UserId") Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Citizen profile", citizenService.getProfile(userId)));
    }

    @GetMapping
    @Operation(summary = "[ADMIN/DOCTOR/NURSE] Get all citizens")
    public ResponseEntity<ApiResponse<List<Citizen>>> getAll() {
        return ResponseEntity.ok(ApiResponse.ok("All citizens", citizenService.getAll()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get citizen by ID")
    public ResponseEntity<ApiResponse<Citizen>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Citizen", citizenService.getById(id)));
    }

    @PostMapping(value = "/{id}/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "[CITIZEN] Upload a document")
    public ResponseEntity<ApiResponse<CitizenDocument>> uploadDocument(
            @PathVariable Long id,
            @RequestParam("file") MultipartFile file) throws IOException {
        CitizenDocument doc = citizenService.uploadDocument(id, file.getBytes());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Document uploaded", doc));
    }

    @GetMapping("/{id}/documents")
    @Operation(summary = "[ADMIN/DOCTOR/NURSE] Get citizen documents")
    public ResponseEntity<ApiResponse<List<CitizenDocument>>> getDocuments(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Documents", citizenService.getDocuments(id)));
    }

    @PatchMapping("/documents/{docId}/verify")
    @Operation(summary = "[ADMIN] Verify or reject a document")
    public ResponseEntity<ApiResponse<CitizenDocument>> verifyDocument(
            @PathVariable Long docId,
            @RequestParam CitizenDocument.VerificationStatus status) {
        return ResponseEntity.ok(ApiResponse.ok("Document status updated to " + status,
                citizenService.verifyDocument(docId, status)));
    }
}
