package com.citycare.citizenservice.controller;

import com.citycare.citizenservice.dto.ApiResponse;
import com.citycare.citizenservice.dto.CitizenInternalCreateRequest;
import com.citycare.citizenservice.entity.Citizen;
import com.citycare.citizenservice.service.CitizenService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Internal endpoints called by other microservices via OpenFeign.
 * These are NOT exposed to external clients (protected by API gateway routing rules).
 */
@RestController
@RequestMapping("/citizens/internal")
@RequiredArgsConstructor
@Tag(name = "Citizen-Internal", description = "Internal endpoints for OpenFeign inter-service calls")
public class InternalCitizenController {

    private final CitizenService citizenService;

    /**
     * Called by auth-service via OpenFeign immediately after a new CITIZEN registers.
     * Auto-creates a basic citizen profile so the citizen row exists from day one.
     */
    @PostMapping("/create")
    @Operation(summary = "[INTERNAL/OpenFeign] Auto-create citizen profile on user registration")
    public ResponseEntity<ApiResponse<Citizen>> createCitizenFromRegistration(
            @Valid @RequestBody CitizenInternalCreateRequest request) {
        Citizen citizen = citizenService.createCitizenFromRegistration(
                request.getUserId(), request.getName(), request.getContactInfo());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Citizen profile auto-created", citizen));
    }

    /**
     * Called by emergency-service / compliance-service via OpenFeign to check if a citizen exists.
     */
    @GetMapping("/user/{userId}")
    @Operation(summary = "[INTERNAL/OpenFeign] Get citizen by userId")
    public ResponseEntity<ApiResponse<Citizen>> getByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Citizen",
                citizenService.getProfile(userId)));
    }
}
