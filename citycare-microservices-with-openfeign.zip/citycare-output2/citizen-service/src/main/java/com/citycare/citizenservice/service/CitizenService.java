package com.citycare.citizenservice.service;

import com.citycare.citizenservice.dto.CitizenProfileRequest;
import com.citycare.citizenservice.entity.Citizen;
import com.citycare.citizenservice.entity.CitizenDocument;
import com.citycare.citizenservice.exception.ResourceNotFoundException;
import com.citycare.citizenservice.repository.CitizenDocumentRepository;
import com.citycare.citizenservice.repository.CitizenRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CitizenService {

    private final CitizenRepository citizenRepository;
    private final CitizenDocumentRepository documentRepository;

    // ── Called by auth-service via OpenFeign on citizen registration ──────────

    /**
     * Auto-creates a minimal citizen profile when a new user registers.
     * Called internally by auth-service via OpenFeign — not by the user directly.
     * If a profile already exists for this userId (e.g. idempotency), it is returned as-is.
     */
    @Transactional
    public Citizen createCitizenFromRegistration(Long userId, String name, String contactInfo) {
        // Idempotent: if profile already exists, return it
        return citizenRepository.findByUserId(userId).orElseGet(() -> {
            log.info("Auto-creating citizen profile for userId={}, name={}", userId, name);
            Citizen citizen = Citizen.builder()
                    .userId(userId)
                    .name(name)
                    .contactInfo(contactInfo)
                    .status(Citizen.Status.ACTIVE)
                    .build();
            return citizenRepository.save(citizen);
        });
    }

    // ── Standard CRUD ─────────────────────────────────────────────────────────

    @Transactional
    public Citizen createOrUpdateProfile(Long userId, CitizenProfileRequest req) {
        Citizen existing = citizenRepository.findByUserId(userId).orElse(null);

        Citizen citizen = Citizen.builder()
                .citizenId(existing != null ? existing.getCitizenId() : null)
                .userId(userId)
                .name(req.getName())
                .dateOfBirth(req.getDateOfBirth())
                .gender(req.getGender())
                .address(req.getAddress())
                .contactInfo(req.getContactInfo())
                .status(Citizen.Status.ACTIVE)
                .build();

        return citizenRepository.save(citizen);
    }

    public Citizen getProfile(Long userId) {
        return citizenRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen profile not found for userId: " + userId));
    }

    public Citizen getById(Long citizenId) {
        return citizenRepository.findById(citizenId)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen", citizenId));
    }

    public List<Citizen> getAll() {
        return citizenRepository.findAll();
    }

    @Transactional
    public CitizenDocument uploadDocument(Long citizenId, byte[] documentData) {
        Citizen citizen = citizenRepository.findById(citizenId)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen", citizenId));

        CitizenDocument doc = CitizenDocument.builder()
                .citizen(citizen)
                .documentData(documentData)
                .uploadedDate(LocalDate.now())
                .verificationStatus(CitizenDocument.VerificationStatus.PENDING)
                .build();

        return documentRepository.save(doc);
    }

    @Transactional
    public CitizenDocument verifyDocument(Long documentId, CitizenDocument.VerificationStatus status) {
        CitizenDocument doc = documentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException("Document", documentId));
        doc.setVerificationStatus(status);
        return documentRepository.save(doc);
    }

    public List<CitizenDocument> getDocuments(Long citizenId) {
        if (!citizenRepository.existsById(citizenId)) {
            throw new ResourceNotFoundException("Citizen", citizenId);
        }
        return documentRepository.findByCitizenCitizenId(citizenId);
    }
}
