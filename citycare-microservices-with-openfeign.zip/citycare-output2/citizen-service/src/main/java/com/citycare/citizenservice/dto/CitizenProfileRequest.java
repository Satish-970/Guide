package com.citycare.citizenservice.dto;

import com.citycare.citizenservice.entity.Citizen;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDate;

@Data
public class CitizenProfileRequest {
    @NotBlank private String name;
    private LocalDate dateOfBirth;
    private Citizen.Gender gender;
    private String address;
    private String contactInfo;
}
