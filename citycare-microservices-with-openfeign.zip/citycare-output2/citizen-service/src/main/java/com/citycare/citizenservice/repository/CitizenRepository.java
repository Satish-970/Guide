package com.citycare.citizenservice.repository;

import com.citycare.citizenservice.entity.Citizen;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CitizenRepository extends JpaRepository<Citizen, Long> {
    Optional<Citizen> findByUserId(Long userId);
    boolean existsByUserId(Long userId);
}
