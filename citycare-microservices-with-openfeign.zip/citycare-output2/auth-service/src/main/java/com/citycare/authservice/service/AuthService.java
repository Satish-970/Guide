package com.citycare.authservice.service;

import com.citycare.authservice.dto.AuthResponse;
import com.citycare.authservice.dto.CreateStaffRequest;
import com.citycare.authservice.dto.RegisterRequest;
import com.citycare.authservice.entity.User;
import com.citycare.authservice.exception.ResourceNotFoundException;
import com.citycare.authservice.feign.CitizenClient;
import com.citycare.authservice.feign.dto.CitizenCreateRequest;
import com.citycare.authservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // OpenFeign: auto-create citizen profile after citizen registration
    private final CitizenClient citizenClient;

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already registered: " + request.getEmail());
        }
        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phone(request.getPhone())
                .role(User.Role.CITIZEN)
                .status(User.Status.ACTIVE)
                .build();
        User savedUser = userRepository.save(user);

        // Auto-create citizen profile in citizen-service via OpenFeign
        try {
            CitizenCreateRequest citizenReq = CitizenCreateRequest.builder()
                    .userId(savedUser.getUserId())
                    .name(savedUser.getName())
                    .contactInfo(savedUser.getPhone())
                    .build();
            var citizenResp = citizenClient.createCitizenProfile(citizenReq);
            if (citizenResp != null) {
                log.info("Auto-created citizen profile (citizenId={}) for userId={}",
                        citizenResp.getCitizenId(), savedUser.getUserId());
            }
        } catch (Exception e) {
            // Non-fatal: user is registered; citizen can create profile later
            log.warn("Could not auto-create citizen profile for userId={}: {}", savedUser.getUserId(), e.getMessage());
        }

        return mapToResponse(savedUser);
    }

    @Transactional
    public User createStaff(CreateStaffRequest req) {
        validateUniqueEmail(req.getEmail());
        return userRepository.save(User.builder()
                .name(req.getName()).email(req.getEmail())
                .password(passwordEncoder.encode(req.getPassword()))
                .phone(req.getPhone()).role(req.getRole())
                .status(User.Status.ACTIVE).build());
    }

    @Transactional
    public User createDispatcher(CreateStaffRequest req) {
        validateUniqueEmail(req.getEmail());
        return userRepository.save(User.builder()
                .name(req.getName()).email(req.getEmail())
                .password(passwordEncoder.encode(req.getPassword()))
                .phone(req.getPhone()).role(User.Role.DISPATCHER)
                .status(User.Status.ACTIVE).build());
    }

    @Transactional
    public User createComplianceOfficer(CreateStaffRequest req) {
        validateUniqueEmail(req.getEmail());
        return userRepository.save(User.builder()
                .name(req.getName()).email(req.getEmail())
                .password(passwordEncoder.encode(req.getPassword()))
                .phone(req.getPhone()).role(User.Role.COMPLIANCE_OFFICER)
                .status(User.Status.ACTIVE).build());
    }

    @Transactional
    public User createCityHealthOfficer(CreateStaffRequest req) {
        validateUniqueEmail(req.getEmail());
        return userRepository.save(User.builder()
                .name(req.getName()).email(req.getEmail())
                .password(passwordEncoder.encode(req.getPassword()))
                .phone(req.getPhone()).role(User.Role.CITY_HEALTH_OFFICER)
                .status(User.Status.ACTIVE).build());
    }

    public List<User> getAllStaff() {
        return userRepository.findByRoleIn(List.of(User.Role.DOCTOR, User.Role.NURSE));
    }

    public List<User> getAllDispatchers() {
        return userRepository.findByRoleIn(List.of(User.Role.DISPATCHER));
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
    }

    @Transactional
    public User deactivateUser(Long id) {
        User user = getUserById(id);
        user.setStatus(User.Status.INACTIVE);
        return userRepository.save(user);
    }

    @Transactional
    public User activateUser(Long id) {
        User user = getUserById(id);
        user.setStatus(User.Status.ACTIVE);
        return userRepository.save(user);
    }

    private void validateUniqueEmail(String email) {
        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("Email already in use: " + email);
        }
    }

    private AuthResponse mapToResponse(User user) {
        return AuthResponse.builder()
                .userId(user.getUserId()).name(user.getName())
                .email(user.getEmail()).role(user.getRole()).build();
    }
}
