# CityCare Microservices

Monolith-to-microservices conversion of the CityCare Urban Healthcare & Emergency Response System.

## Architecture

```
                        ┌─────────────────────┐
                        │    config-server     │  :8888
                        │  (Spring Cloud Config│
                        │   native classpath)  │
                        └──────────┬──────────┘
                                   │ serves .properties to all services
                        ┌──────────▼──────────┐
                        │    eureka-server     │  :8761
                        │  (Service Registry)  │
                        └──────────┬──────────┘
                                   │ all services register here
                        ┌──────────▼──────────┐
                        │     api-gateway      │  :8080
                        │  (JWT Filter + LB)   │
                        └──────────┬──────────┘
          ┌──────────┬─────────────┼──────────────┬──────────┬────────────┐
          │          │             │               │          │            │
    ┌─────▼───┐ ┌────▼────┐ ┌─────▼──────┐ ┌─────▼───┐ ┌────▼────┐ ┌────▼──────┐
    │  auth   │ │citizen  │ │ emergency  │ │ patient │ │facility │ │compliance │
    │ :8081   │ │ :8082   │ │   :8083    │ │  :8084  │ │  :8085  │ │  :8086    │
    └─────────┘ └─────────┘ └────────────┘ └─────────┘ └─────────┘ └───────────┘
    citycare_   citycare_   citycare_       citycare_   citycare_   citycare_
    auth        citizen     emergency       patient     facility    compliance
```

## Service Summary

| Service                   | Port | Database              | Description                              |
|---------------------------|------|-----------------------|------------------------------------------|
| `config-server`           | 8888 | —                     | Centralized config (native classpath)    |
| `eureka-server`           | 8761 | —                     | Service Registry                         |
| `api-gateway`             | 8080 | —                     | JWT validation + routing                 |
| `auth-service`            | 8081 | citycare_auth         | Register, Login, User Management         |
| `citizen-service`         | 8082 | citycare_citizen      | Citizen profiles & documents             |
| `emergency-service`       | 8083 | citycare_emergency    | Emergency reporting & ambulance dispatch |
| `patient-treatment-service` | 8084 | citycare_patient    | Patient admission & treatments           |
| `facility-service`        | 8085 | citycare_facility     | Facility & staff management              |
| `compliance-service`      | 8086 | citycare_compliance   | Compliance records & audits              |

## Prerequisites

- Java 21
- Maven 3.9+
- PostgreSQL 15+

## Database Setup

Run once as a PostgreSQL superuser:

```sql
CREATE DATABASE citycare_auth;
CREATE DATABASE citycare_citizen;
CREATE DATABASE citycare_emergency;
CREATE DATABASE citycare_patient;
CREATE DATABASE citycare_facility;
CREATE DATABASE citycare_compliance;
```

Update credentials in:
`config-server/src/main/resources/config/<service-name>.properties`

Default credentials are `postgres / postgres`.

## Startup Order

Start services **in this exact order**:

```bash
# 1. Config Server
cd config-server && mvn spring-boot:run

# 2. Eureka Server
cd eureka-server && mvn spring-boot:run

# 3. API Gateway
cd api-gateway && mvn spring-boot:run

# 4. Business Services (any order)
cd auth-service             && mvn spring-boot:run &
cd citizen-service          && mvn spring-boot:run &
cd emergency-service        && mvn spring-boot:run &
cd patient-treatment-service && mvn spring-boot:run &
cd facility-service         && mvn spring-boot:run &
cd compliance-service       && mvn spring-boot:run &
```

## JWT Token Flow

1. `POST /auth/register` → creates account, returns user info
2. `POST /auth/login`    → returns `{ "token": "Bearer ..." }`
3. All subsequent requests: `Authorization: Bearer <token>`

The API Gateway validates the JWT and forwards `X-Auth-User` and `X-Auth-UserId` headers to downstream services.

## Key Design Decisions (Monolith → Microservices)

- **No shared database**: each service owns its schema.
- **No JPA foreign keys across services**: cross-service references stored as plain `Long` IDs (e.g. `citizenId`, `officerId`).
- **Config-first**: every service fetches its full config from `config-server` on startup.
- **JWT shared secret**: the same `jwt.secret` in `application.properties` (config-server) is used by the gateway filter and all services that need to validate tokens locally.
- **X-Auth-UserId header**: the API Gateway extracts the userId from the JWT and forwards it as `X-Auth-UserId` so services don't need to call auth-service on every request.

## Swagger UI per Service

| Service                   | URL                                          |
|---------------------------|----------------------------------------------|
| auth-service              | http://localhost:8081/api/swagger-ui.html    |
| citizen-service           | http://localhost:8082/api/swagger-ui.html    |
| emergency-service         | http://localhost:8083/api/swagger-ui.html    |
| patient-treatment-service | http://localhost:8084/api/swagger-ui.html    |
| facility-service          | http://localhost:8085/api/swagger-ui.html    |
| compliance-service        | http://localhost:8086/api/swagger-ui.html    |

Eureka Dashboard: http://localhost:8761
