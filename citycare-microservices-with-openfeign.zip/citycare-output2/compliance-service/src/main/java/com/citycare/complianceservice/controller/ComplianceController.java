package com.citycare.complianceservice.controller;

import com.citycare.complianceservice.dto.ApiResponse;
import com.citycare.complianceservice.dto.AuditRequest;
import com.citycare.complianceservice.dto.ComplianceRecordRequest;
import com.citycare.complianceservice.entity.Audit;
import com.citycare.complianceservice.entity.AuditLog;
import com.citycare.complianceservice.entity.ComplianceRecord;
import com.citycare.complianceservice.service.ComplianceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/compliance")
@RequiredArgsConstructor
@Tag(name = "Compliance", description = "Compliance records, audits, and audit logs")
public class ComplianceController {

    private final ComplianceService complianceService;

    // ── Compliance Records ────────────────────────────────────────────────────

    @PostMapping("/records")
    @Operation(summary = "[COMPLIANCE_OFFICER/ADMIN] Create compliance record")
    public ResponseEntity<ApiResponse<ComplianceRecord>> createRecord(
            @Valid @RequestBody ComplianceRecordRequest request,
            @RequestHeader("X-Auth-UserId") Long officerId) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Compliance record created",
                        complianceService.createRecord(officerId, request)));
    }

    @GetMapping("/records")
    @Operation(summary = "[ADMIN/COMPLIANCE_OFFICER] Get all compliance records")
    public ResponseEntity<ApiResponse<List<ComplianceRecord>>> getAllRecords() {
        return ResponseEntity.ok(ApiResponse.ok("All compliance records", complianceService.getAllRecords()));
    }

    @GetMapping("/records/{id}")
    @Operation(summary = "Get compliance record by ID")
    public ResponseEntity<ApiResponse<ComplianceRecord>> getRecordById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Compliance record", complianceService.getRecordById(id)));
    }

    @GetMapping("/records/entity/{entityId}")
    @Operation(summary = "Get compliance records by entity ID")
    public ResponseEntity<ApiResponse<List<ComplianceRecord>>> getByEntity(@PathVariable Long entityId) {
        return ResponseEntity.ok(ApiResponse.ok("Records for entity " + entityId,
                complianceService.getRecordsByEntity(entityId)));
    }

    @GetMapping("/records/type/{type}")
    @Operation(summary = "Get compliance records by type (FACILITY/PATIENT/EMERGENCY)")
    public ResponseEntity<ApiResponse<List<ComplianceRecord>>> getByType(
            @PathVariable ComplianceRecord.EntityType type) {
        return ResponseEntity.ok(ApiResponse.ok("Records by type: " + type,
                complianceService.getRecordsByType(type)));
    }

    // ── Audits ────────────────────────────────────────────────────────────────

    @PostMapping("/audits")
    @Operation(summary = "[COMPLIANCE_OFFICER/ADMIN] Create audit")
    public ResponseEntity<ApiResponse<Audit>> createAudit(
            @Valid @RequestBody AuditRequest request,
            @RequestHeader("X-Auth-UserId") Long officerId) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Audit created", complianceService.createAudit(officerId, request)));
    }

    @GetMapping("/audits")
    @Operation(summary = "[ADMIN/COMPLIANCE_OFFICER] Get all audits")
    public ResponseEntity<ApiResponse<List<Audit>>> getAllAudits() {
        return ResponseEntity.ok(ApiResponse.ok("All audits", complianceService.getAllAudits()));
    }

    @GetMapping("/audits/{id}")
    @Operation(summary = "Get audit by ID")
    public ResponseEntity<ApiResponse<Audit>> getAudit(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Audit", complianceService.getAuditById(id)));
    }

    @PatchMapping("/audits/{id}/status")
    @Operation(summary = "[COMPLIANCE_OFFICER/ADMIN] Update audit status")
    public ResponseEntity<ApiResponse<Audit>> updateAuditStatus(
            @PathVariable Long id,
            @RequestParam Audit.Status status,
            @RequestParam(required = false) String findings) {
        return ResponseEntity.ok(ApiResponse.ok("Audit updated",
                complianceService.updateAuditStatus(id, status, findings)));
    }

    // ── Audit Logs ────────────────────────────────────────────────────────────

    @GetMapping("/logs")
    @Operation(summary = "[ADMIN] Get all audit logs")
    public ResponseEntity<ApiResponse<List<AuditLog>>> getLogs() {
        return ResponseEntity.ok(ApiResponse.ok("Audit logs", complianceService.getAllLogs()));
    }

    @GetMapping("/logs/user/{userId}")
    @Operation(summary = "[ADMIN] Get audit logs by user")
    public ResponseEntity<ApiResponse<List<AuditLog>>> getLogsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Logs for user " + userId,
                complianceService.getLogsByUser(userId)));
    }
}
