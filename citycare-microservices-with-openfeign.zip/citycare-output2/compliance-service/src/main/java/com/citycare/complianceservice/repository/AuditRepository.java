package com.citycare.complianceservice.repository;

import com.citycare.complianceservice.entity.Audit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditRepository extends JpaRepository<Audit, Long> {}
