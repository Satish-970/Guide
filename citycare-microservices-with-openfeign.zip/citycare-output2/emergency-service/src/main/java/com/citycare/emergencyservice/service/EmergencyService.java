package com.citycare.emergencyservice.service;

import com.citycare.emergencyservice.dto.AmbulanceRequest;
import com.citycare.emergencyservice.dto.DispatchRequest;
import com.citycare.emergencyservice.dto.EmergencyRequest;
import com.citycare.emergencyservice.entity.Ambulance;
import com.citycare.emergencyservice.entity.Emergency;
import com.citycare.emergencyservice.exception.BadRequestException;
import com.citycare.emergencyservice.exception.ResourceNotFoundException;
import com.citycare.emergencyservice.feign.CitizenClient;
import com.citycare.emergencyservice.feign.dto.CitizenResponse;
import com.citycare.emergencyservice.repository.AmbulanceRepository;
import com.citycare.emergencyservice.repository.EmergencyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmergencyService {

    private final EmergencyRepository emergencyRepository;
    private final AmbulanceRepository ambulanceRepository;

    // OpenFeign client for cross-service communication
    private final CitizenClient citizenClient;

    @Transactional
    public Emergency reportEmergency(Long citizenId, EmergencyRequest req) {
        // Validate that the citizen exists via citizen-service (OpenFeign)
        try {
            CitizenResponse citizen = citizenClient.getCitizenById(citizenId);
            log.info("Reporting emergency for citizen: {} (id={})", citizen.getName(), citizen.getCitizenId());
        } catch (Exception e) {
            log.warn("Could not validate citizen {} from citizen-service: {}", citizenId, e.getMessage());
        }

        Emergency emergency = Emergency.builder()
                .citizenId(citizenId)
                .type(req.getType())
                .location(req.getLocation())
                .description(req.getDescription())
                .status(Emergency.Status.REPORTED)
                .build();
        return emergencyRepository.save(emergency);
    }

    @Transactional
    public Emergency dispatchAmbulance(Long emergencyId, Long dispatcherId, DispatchRequest req) {
        Emergency emergency = emergencyRepository.findById(emergencyId)
                .orElseThrow(() -> new ResourceNotFoundException("Emergency", emergencyId));

        if (emergency.getStatus() != Emergency.Status.REPORTED) {
            throw new BadRequestException("Cannot dispatch – status is " + emergency.getStatus());
        }

        Ambulance ambulance = ambulanceRepository.findById(req.getAmbulanceId())
                .orElseThrow(() -> new ResourceNotFoundException("Ambulance", req.getAmbulanceId()));

        if (ambulance.getStatus() != Ambulance.Status.AVAILABLE) {
            throw new BadRequestException("Ambulance " + ambulance.getVehicleNumber() + " is not available");
        }

        ambulance.setStatus(Ambulance.Status.DISPATCHED);
        ambulanceRepository.save(ambulance);

        emergency.setStatus(Emergency.Status.DISPATCHED);
        emergency.setDispatcherId(dispatcherId);
        emergency.setAmbulance(ambulance);
        emergency.setDispatchedAt(LocalDateTime.now());
        return emergencyRepository.save(emergency);
    }

    public List<Ambulance> getAvailableAmbulances() {
        return ambulanceRepository.findByStatus(Ambulance.Status.AVAILABLE);
    }

    public List<Emergency> getReportedEmergencies() {
        return emergencyRepository.findByStatusOrderByCreatedAtDesc(Emergency.Status.REPORTED);
    }

    public List<Emergency> getDispatchedEmergencies() {
        return emergencyRepository.findByStatus(Emergency.Status.DISPATCHED);
    }

    public Emergency getById(Long id) {
        return emergencyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Emergency", id));
    }

    public List<Emergency> getMyCases(Long citizenId) {
        return emergencyRepository.findByCitizenId(citizenId);
    }

    /**
     * Update the status of an emergency.
     * Called internally by patient-treatment-service via OpenFeign when a patient is admitted or discharged.
     */
    @Transactional
    public Emergency updateEmergencyStatus(Long emergencyId, String statusStr) {
        Emergency emergency = emergencyRepository.findById(emergencyId)
                .orElseThrow(() -> new ResourceNotFoundException("Emergency", emergencyId));
        Emergency.Status status = Emergency.Status.valueOf(statusStr.toUpperCase());
        emergency.setStatus(status);
        log.info("Emergency {} status updated to {} (called via OpenFeign)", emergencyId, status);
        return emergencyRepository.save(emergency);
    }

    /**
     * Fetch citizen info from citizen-service for a given emergency.
     * Enriches emergency data with citizen contact details via OpenFeign.
     */
    public CitizenResponse getCitizenForEmergency(Long emergencyId) {
        Emergency emergency = getById(emergencyId);
        return citizenClient.getCitizenById(emergency.getCitizenId());
    }

    // ── Ambulance management (admin) ──────────────────────────────────────────
    @Transactional
    public Ambulance addAmbulance(AmbulanceRequest req) {
        return ambulanceRepository.save(Ambulance.builder()
                .vehicleNumber(req.getVehicleNumber())
                .model(req.getModel())
                .status(Ambulance.Status.AVAILABLE)
                .build());
    }

    public List<Ambulance> getAllAmbulances() {
        return ambulanceRepository.findAll();
    }

    @Transactional
    public Ambulance updateAmbulanceStatus(Long id, Ambulance.Status status) {
        Ambulance amb = ambulanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ambulance", id));
        amb.setStatus(status);
        return ambulanceRepository.save(amb);
    }
}
