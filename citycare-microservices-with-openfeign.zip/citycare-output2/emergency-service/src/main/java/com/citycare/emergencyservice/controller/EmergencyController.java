package com.citycare.emergencyservice.controller;

import com.citycare.emergencyservice.dto.AmbulanceRequest;
import com.citycare.emergencyservice.dto.ApiResponse;
import com.citycare.emergencyservice.dto.DispatchRequest;
import com.citycare.emergencyservice.dto.EmergencyRequest;
import com.citycare.emergencyservice.entity.Ambulance;
import com.citycare.emergencyservice.entity.Emergency;
import com.citycare.emergencyservice.feign.dto.CitizenResponse;
import com.citycare.emergencyservice.service.EmergencyService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/emergencies")
@RequiredArgsConstructor
@Tag(name = "Emergency", description = "Emergency reporting and ambulance dispatch")
public class EmergencyController {

    private final EmergencyService emergencyService;

    @PostMapping("/report")
    @Operation(summary = "[CITIZEN] Report an emergency – validates citizen via OpenFeign")
    public ResponseEntity<ApiResponse<Emergency>> report(
            @Valid @RequestBody EmergencyRequest request,
            @RequestHeader("X-Auth-UserId") Long citizenId) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Emergency reported. Help is on the way.",
                        emergencyService.reportEmergency(citizenId, request)));
    }

    @GetMapping("/my")
    @Operation(summary = "[CITIZEN] Get my emergencies")
    public ResponseEntity<ApiResponse<List<Emergency>>> myEmergencies(
            @RequestHeader("X-Auth-UserId") Long citizenId) {
        return ResponseEntity.ok(ApiResponse.ok("My emergencies", emergencyService.getMyCases(citizenId)));
    }

    @GetMapping("/pending")
    @Operation(summary = "[DISPATCHER] View all pending (REPORTED) emergencies")
    public ResponseEntity<ApiResponse<List<Emergency>>> getPending() {
        return ResponseEntity.ok(ApiResponse.ok("Pending emergencies", emergencyService.getReportedEmergencies()));
    }

    @GetMapping("/ambulances/available")
    @Operation(summary = "[DISPATCHER] View available ambulances")
    public ResponseEntity<ApiResponse<List<Ambulance>>> getAvailableAmbulances() {
        return ResponseEntity.ok(ApiResponse.ok("Available ambulances", emergencyService.getAvailableAmbulances()));
    }

    @PostMapping("/{id}/dispatch")
    @Operation(summary = "[DISPATCHER] Dispatch ambulance to emergency")
    public ResponseEntity<ApiResponse<Emergency>> dispatch(
            @PathVariable Long id,
            @Valid @RequestBody DispatchRequest request,
            @RequestHeader("X-Auth-UserId") Long dispatcherId) {
        return ResponseEntity.ok(ApiResponse.ok("Ambulance dispatched",
                emergencyService.dispatchAmbulance(id, dispatcherId, request)));
    }

    @GetMapping("/dispatched")
    @Operation(summary = "[ADMIN/CITY_HEALTH_OFFICER] View dispatched emergencies")
    public ResponseEntity<ApiResponse<List<Emergency>>> getDispatched() {
        return ResponseEntity.ok(ApiResponse.ok("Dispatched emergencies", emergencyService.getDispatchedEmergencies()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get emergency by ID")
    public ResponseEntity<ApiResponse<Emergency>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Emergency", emergencyService.getById(id)));
    }

    /**
     * Internal endpoint called by patient-treatment-service via OpenFeign to update emergency status.
     */
    @PatchMapping("/{id}/status")
    @Operation(summary = "[INTERNAL/OpenFeign] Update emergency status – called by patient-treatment-service")
    public ResponseEntity<ApiResponse<Emergency>> updateStatus(
            @PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(ApiResponse.ok("Emergency status updated to " + status,
                emergencyService.updateEmergencyStatus(id, status)));
    }

    /**
     * OpenFeign enrichment: fetch citizen details for this emergency.
     */
    @GetMapping("/{id}/citizen")
    @Operation(summary = "Get citizen details for emergency (via OpenFeign → citizen-service)")
    public ResponseEntity<ApiResponse<CitizenResponse>> getCitizenForEmergency(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Citizen for emergency " + id,
                emergencyService.getCitizenForEmergency(id)));
    }

    // ── Admin: Ambulance management ───────────────────────────────────────────

    @PostMapping("/admin/ambulances")
    @Operation(summary = "[ADMIN] Add ambulance to fleet")
    public ResponseEntity<ApiResponse<Ambulance>> addAmbulance(@Valid @RequestBody AmbulanceRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Ambulance added", emergencyService.addAmbulance(request)));
    }

    @GetMapping("/admin/ambulances")
    @Operation(summary = "[ADMIN] List all ambulances")
    public ResponseEntity<ApiResponse<List<Ambulance>>> getAllAmbulances() {
        return ResponseEntity.ok(ApiResponse.ok("All ambulances", emergencyService.getAllAmbulances()));
    }

    @PatchMapping("/admin/ambulances/{id}/status")
    @Operation(summary = "[ADMIN] Update ambulance status")
    public ResponseEntity<ApiResponse<Ambulance>> updateAmbulanceStatus(
            @PathVariable Long id, @RequestParam Ambulance.Status status) {
        return ResponseEntity.ok(ApiResponse.ok("Status updated to " + status,
                emergencyService.updateAmbulanceStatus(id, status)));
    }
}
