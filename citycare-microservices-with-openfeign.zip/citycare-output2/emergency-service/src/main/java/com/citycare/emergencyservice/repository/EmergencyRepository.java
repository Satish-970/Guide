package com.citycare.emergencyservice.repository;

import com.citycare.emergencyservice.entity.Emergency;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmergencyRepository extends JpaRepository<Emergency, Long> {
    List<Emergency> findByStatusOrderByCreatedAtDesc(Emergency.Status status);
    List<Emergency> findByStatus(Emergency.Status status);
    List<Emergency> findByCitizenId(Long citizenId);
}
