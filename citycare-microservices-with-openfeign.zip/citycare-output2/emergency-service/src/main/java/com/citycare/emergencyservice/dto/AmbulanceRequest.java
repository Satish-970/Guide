package com.citycare.emergencyservice.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AmbulanceRequest {
    @NotBlank private String vehicleNumber;
    private String model;
}
