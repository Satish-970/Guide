package com.citycare.emergencyservice.feign;

import com.citycare.emergencyservice.feign.dto.CitizenResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "citizen-service", fallback = CitizenClientFallback.class)
public interface CitizenClient {

    @GetMapping("/citizens/{id}")
    CitizenResponse getCitizenById(@PathVariable("id") Long citizenId);

    @GetMapping("/citizens/user/{userId}")
    CitizenResponse getCitizenByUserId(@PathVariable("userId") Long userId);
}
