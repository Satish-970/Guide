package com.citycare.emergencyservice.feign;

import com.citycare.emergencyservice.feign.dto.CitizenResponse;
import org.springframework.stereotype.Component;

@Component
public class CitizenClientFallback implements CitizenClient {

    @Override
    public CitizenResponse getCitizenById(Long citizenId) {
        CitizenResponse fallback = new CitizenResponse();
        fallback.setCitizenId(citizenId);
        fallback.setName("Unknown (citizen-service unavailable)");
        fallback.setStatus("UNKNOWN");
        return fallback;
    }

    @Override
    public CitizenResponse getCitizenByUserId(Long userId) {
        CitizenResponse fallback = new CitizenResponse();
        fallback.setUserId(userId);
        fallback.setName("Unknown (citizen-service unavailable)");
        fallback.setStatus("UNKNOWN");
        return fallback;
    }
}
