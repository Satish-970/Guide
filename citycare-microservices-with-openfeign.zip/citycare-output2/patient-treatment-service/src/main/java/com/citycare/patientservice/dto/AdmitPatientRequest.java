package com.citycare.patientservice.dto;

import com.citycare.patientservice.entity.Patient;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

@Data
public class AdmitPatientRequest {
    @NotNull private Long citizenId;
    @NotNull private Long emergencyId;
    @NotNull private LocalDate admissionDate;
    private String ward;
    private String notes;
}
