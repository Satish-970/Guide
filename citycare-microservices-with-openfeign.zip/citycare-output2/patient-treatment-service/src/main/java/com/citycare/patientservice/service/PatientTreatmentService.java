package com.citycare.patientservice.service;

import com.citycare.patientservice.dto.AdmitPatientRequest;
import com.citycare.patientservice.dto.TreatmentRequest;
import com.citycare.patientservice.entity.Patient;
import com.citycare.patientservice.entity.Treatment;
import com.citycare.patientservice.exception.ResourceNotFoundException;
import com.citycare.patientservice.feign.CitizenClient;
import com.citycare.patientservice.feign.EmergencyClient;
import com.citycare.patientservice.feign.dto.CitizenResponse;
import com.citycare.patientservice.feign.dto.EmergencyResponse;
import com.citycare.patientservice.repository.PatientRepository;
import com.citycare.patientservice.repository.TreatmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PatientTreatmentService {

    private final PatientRepository patientRepository;
    private final TreatmentRepository treatmentRepository;

    // OpenFeign clients for cross-service communication
    private final CitizenClient citizenClient;
    private final EmergencyClient emergencyClient;

    // ── Patient ───────────────────────────────────────────────────────────────

    @Transactional
    public Patient admitPatient(AdmitPatientRequest req) {
        // Validate that the citizen exists via citizen-service (OpenFeign)
        try {
            CitizenResponse citizen = citizenClient.getCitizenById(req.getCitizenId());
            log.info("Validated citizen: {} (id={})", citizen.getName(), citizen.getCitizenId());
        } catch (Exception e) {
            log.warn("Could not validate citizen {} from citizen-service: {}", req.getCitizenId(), e.getMessage());
        }

        // Validate that the emergency exists and is in DISPATCHED state via emergency-service (OpenFeign)
        try {
            EmergencyResponse emergency = emergencyClient.getEmergencyById(req.getEmergencyId());
            log.info("Validated emergency id={} with status={}", emergency.getEmergencyId(), emergency.getStatus());
            // Update emergency status to ADMITTED
            emergencyClient.updateEmergencyStatus(req.getEmergencyId(), "ADMITTED");
            log.info("Updated emergency {} status to ADMITTED", req.getEmergencyId());
        } catch (Exception e) {
            log.warn("Could not update emergency {} status via emergency-service: {}", req.getEmergencyId(), e.getMessage());
        }

        Patient patient = Patient.builder()
                .citizenId(req.getCitizenId())
                .emergencyId(req.getEmergencyId())
                .admissionDate(req.getAdmissionDate())
                .ward(req.getWard())
                .notes(req.getNotes())
                .status(Patient.Status.ADMITTED)
                .build();
        return patientRepository.save(patient);
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public Patient getPatientById(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient", id));
    }

    @Transactional
    public Patient updatePatientStatus(Long id, Patient.Status status) {
        Patient patient = getPatientById(id);
        patient.setStatus(status);

        // When a patient is discharged, notify emergency-service to close the emergency (OpenFeign)
        if (status == Patient.Status.DISCHARGED) {
            try {
                emergencyClient.updateEmergencyStatus(patient.getEmergencyId(), "CLOSED");
                log.info("Closed emergency {} after patient {} discharge", patient.getEmergencyId(), id);
            } catch (Exception e) {
                log.warn("Could not close emergency {} via emergency-service: {}", patient.getEmergencyId(), e.getMessage());
            }
        }

        return patientRepository.save(patient);
    }

    // ── Treatment ─────────────────────────────────────────────────────────────

    @Transactional
    public Treatment addTreatment(Long assignedById, TreatmentRequest req) {
        Patient patient = patientRepository.findById(req.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient", req.getPatientId()));

        Treatment treatment = Treatment.builder()
                .patient(patient)
                .assignedById(assignedById)
                .description(req.getDescription())
                .medicationName(req.getMedicationName())
                .dosage(req.getDosage())
                .endDate(req.getEndDate())
                .status(Treatment.Status.ONGOING)
                .build();
        return treatmentRepository.save(treatment);
    }

    public List<Treatment> getTreatmentsByPatient(Long patientId) {
        if (!patientRepository.existsById(patientId)) {
            throw new ResourceNotFoundException("Patient", patientId);
        }
        return treatmentRepository.findByPatientPatientId(patientId);
    }

    public Treatment getTreatmentById(Long id) {
        return treatmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Treatment", id));
    }

    @Transactional
    public Treatment updateTreatmentStatus(Long id, Treatment.Status status) {
        Treatment treatment = getTreatmentById(id);
        treatment.setStatus(status);
        return treatmentRepository.save(treatment);
    }

    public List<Treatment> getAllTreatments() {
        return treatmentRepository.findAll();
    }

    // ── Cross-service enrichment ──────────────────────────────────────────────

    /**
     * Fetches citizen details from citizen-service for a given patient.
     * Used to enrich patient data with citizen info via OpenFeign.
     */
    public CitizenResponse getCitizenForPatient(Long patientId) {
        Patient patient = getPatientById(patientId);
        return citizenClient.getCitizenById(patient.getCitizenId());
    }

    /**
     * Fetches emergency details from emergency-service for a given patient.
     */
    public EmergencyResponse getEmergencyForPatient(Long patientId) {
        Patient patient = getPatientById(patientId);
        return emergencyClient.getEmergencyById(patient.getEmergencyId());
    }
}
