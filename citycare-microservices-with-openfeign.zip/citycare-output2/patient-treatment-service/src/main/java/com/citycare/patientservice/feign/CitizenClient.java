package com.citycare.patientservice.feign;

import com.citycare.patientservice.feign.dto.CitizenResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "citizen-service", fallback = CitizenClientFallback.class)
public interface CitizenClient {

    @GetMapping("/citizens/{id}")
    CitizenResponse getCitizenById(@PathVariable("id") Long citizenId);
}
