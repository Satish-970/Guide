package com.citycare.patientservice.feign;

import com.citycare.patientservice.feign.dto.EmergencyResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "emergency-service", fallback = EmergencyClientFallback.class)
public interface EmergencyClient {

    @GetMapping("/emergencies/{id}")
    EmergencyResponse getEmergencyById(@PathVariable("id") Long emergencyId);

    @PatchMapping("/emergencies/{id}/status")
    EmergencyResponse updateEmergencyStatus(@PathVariable("id") Long emergencyId,
                                            @RequestParam("status") String status);
}
