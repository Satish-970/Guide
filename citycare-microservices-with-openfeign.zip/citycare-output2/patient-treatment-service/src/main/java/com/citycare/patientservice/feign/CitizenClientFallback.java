package com.citycare.patientservice.feign;

import com.citycare.patientservice.feign.dto.CitizenResponse;
import org.springframework.stereotype.Component;

@Component
public class CitizenClientFallback implements CitizenClient {

    @Override
    public CitizenResponse getCitizenById(Long citizenId) {
        // Fallback: return a minimal response so the system remains operational
        CitizenResponse fallback = new CitizenResponse();
        fallback.setCitizenId(citizenId);
        fallback.setName("Unknown (citizen-service unavailable)");
        fallback.setStatus("UNKNOWN");
        return fallback;
    }
}
