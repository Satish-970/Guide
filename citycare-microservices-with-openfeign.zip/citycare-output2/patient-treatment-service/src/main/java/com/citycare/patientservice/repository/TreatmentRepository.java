package com.citycare.patientservice.repository;

import com.citycare.patientservice.entity.Treatment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TreatmentRepository extends JpaRepository<Treatment, Long> {
    List<Treatment> findByPatientPatientId(Long patientId);
}
