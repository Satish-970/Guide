package com.citycare.patientservice.controller;

import com.citycare.patientservice.dto.AdmitPatientRequest;
import com.citycare.patientservice.dto.ApiResponse;
import com.citycare.patientservice.dto.TreatmentRequest;
import com.citycare.patientservice.entity.Patient;
import com.citycare.patientservice.entity.Treatment;
import com.citycare.patientservice.feign.dto.CitizenResponse;
import com.citycare.patientservice.feign.dto.EmergencyResponse;
import com.citycare.patientservice.service.PatientTreatmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class PatientTreatmentController {

    private final PatientTreatmentService service;

    // ── Patients ──────────────────────────────────────────────────────────────

    @PostMapping("/patients/admit")
    @Tag(name = "Patient") @Operation(summary = "[ADMIN] Admit a patient – validates citizen & emergency via OpenFeign")
    public ResponseEntity<ApiResponse<Patient>> admit(@Valid @RequestBody AdmitPatientRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Patient admitted", service.admitPatient(req)));
    }

    @GetMapping("/patients")
    @Tag(name = "Patient") @Operation(summary = "[ADMIN/DOCTOR/NURSE] Get all patients")
    public ResponseEntity<ApiResponse<List<Patient>>> getAll() {
        return ResponseEntity.ok(ApiResponse.ok("All patients", service.getAllPatients()));
    }

    @GetMapping("/patients/{id}")
    @Tag(name = "Patient") @Operation(summary = "Get patient by ID")
    public ResponseEntity<ApiResponse<Patient>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Patient", service.getPatientById(id)));
    }

    @PatchMapping("/patients/{id}/status")
    @Tag(name = "Patient") @Operation(summary = "[DOCTOR/NURSE/ADMIN] Update patient status – notifies emergency-service via OpenFeign on DISCHARGED")
    public ResponseEntity<ApiResponse<Patient>> updateStatus(
            @PathVariable Long id, @RequestParam Patient.Status status) {
        return ResponseEntity.ok(ApiResponse.ok("Status updated to " + status,
                service.updatePatientStatus(id, status)));
    }

    /** OpenFeign enrichment: fetch citizen details for a patient */
    @GetMapping("/patients/{id}/citizen")
    @Tag(name = "Patient") @Operation(summary = "Get citizen details for patient (via OpenFeign → citizen-service)")
    public ResponseEntity<ApiResponse<CitizenResponse>> getCitizenForPatient(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Citizen info for patient " + id,
                service.getCitizenForPatient(id)));
    }

    /** OpenFeign enrichment: fetch emergency details for a patient */
    @GetMapping("/patients/{id}/emergency")
    @Tag(name = "Patient") @Operation(summary = "Get emergency details for patient (via OpenFeign → emergency-service)")
    public ResponseEntity<ApiResponse<EmergencyResponse>> getEmergencyForPatient(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Emergency info for patient " + id,
                service.getEmergencyForPatient(id)));
    }

    // ── Treatments ────────────────────────────────────────────────────────────

    @PostMapping("/treatments")
    @Tag(name = "Treatment") @Operation(summary = "[DOCTOR/NURSE] Add treatment to patient")
    public ResponseEntity<ApiResponse<Treatment>> addTreatment(
            @Valid @RequestBody TreatmentRequest req,
            @RequestHeader("X-Auth-UserId") Long assignedById) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Treatment added", service.addTreatment(assignedById, req)));
    }

    @GetMapping("/treatments")
    @Tag(name = "Treatment") @Operation(summary = "[DOCTOR/NURSE] Get all treatments")
    public ResponseEntity<ApiResponse<List<Treatment>>> getAllTreatments() {
        return ResponseEntity.ok(ApiResponse.ok("All treatments", service.getAllTreatments()));
    }

    @GetMapping("/treatments/{id}")
    @Tag(name = "Treatment") @Operation(summary = "Get treatment by ID")
    public ResponseEntity<ApiResponse<Treatment>> getTreatmentById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Treatment", service.getTreatmentById(id)));
    }

    @GetMapping("/patients/{id}/treatments")
    @Tag(name = "Treatment") @Operation(summary = "Get all treatments for a patient")
    public ResponseEntity<ApiResponse<List<Treatment>>> getByPatient(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Treatments for patient " + id,
                service.getTreatmentsByPatient(id)));
    }

    @PatchMapping("/treatments/{id}/status")
    @Tag(name = "Treatment") @Operation(summary = "[DOCTOR/NURSE] Update treatment status")
    public ResponseEntity<ApiResponse<Treatment>> updateTreatmentStatus(
            @PathVariable Long id, @RequestParam Treatment.Status status) {
        return ResponseEntity.ok(ApiResponse.ok("Treatment status updated",
                service.updateTreatmentStatus(id, status)));
    }
}
