package com.citycare.facilityservice.feign;

import com.citycare.facilityservice.feign.dto.UserResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class AuthClientFallback implements AuthClient {

    @Override
    public UserResponse getUserById(Long userId) {
        log.warn("auth-service unavailable – cannot validate userId={}", userId);
        UserResponse fallback = new UserResponse();
        fallback.setUserId(userId);
        fallback.setName("Unknown (auth-service unavailable)");
        fallback.setStatus("UNKNOWN");
        return fallback;
    }
}
