package com.citycare.facilityservice.repository;

import com.citycare.facilityservice.entity.Staff;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StaffRepository extends JpaRepository<Staff, Long> {
    List<Staff> findByFacilityFacilityId(Long facilityId);
}
