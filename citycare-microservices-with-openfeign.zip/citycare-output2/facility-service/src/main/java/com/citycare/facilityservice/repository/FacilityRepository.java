package com.citycare.facilityservice.repository;

import com.citycare.facilityservice.entity.Facility;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FacilityRepository extends JpaRepository<Facility, Long> {}
