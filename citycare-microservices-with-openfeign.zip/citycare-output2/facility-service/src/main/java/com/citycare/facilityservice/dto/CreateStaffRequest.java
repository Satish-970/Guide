package com.citycare.facilityservice.dto;

import com.citycare.facilityservice.entity.Staff;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreateStaffRequest {
    @NotBlank private String name;
    @NotNull  private Staff.Role role;
    @NotNull  private Long facilityId;
    private String contactInfo;
    private Long userId;
}
