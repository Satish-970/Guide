package com.citycare.facilityservice.controller;

import com.citycare.facilityservice.dto.ApiResponse;
import com.citycare.facilityservice.dto.CreateStaffRequest;
import com.citycare.facilityservice.dto.FacilityRequest;
import com.citycare.facilityservice.entity.Facility;
import com.citycare.facilityservice.entity.Staff;
import com.citycare.facilityservice.feign.dto.UserResponse;
import com.citycare.facilityservice.service.FacilityService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/facilities")
@RequiredArgsConstructor
@Tag(name = "Facility", description = "Facility and staff management")
public class FacilityController {

    private final FacilityService facilityService;

    @PostMapping
    @Operation(summary = "[ADMIN] Create a facility")
    public ResponseEntity<ApiResponse<Facility>> create(@Valid @RequestBody FacilityRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Facility created", facilityService.createFacility(req)));
    }

    @GetMapping
    @Operation(summary = "[ADMIN/CITY_HEALTH_OFFICER] List all facilities")
    public ResponseEntity<ApiResponse<List<Facility>>> getAll() {
        return ResponseEntity.ok(ApiResponse.ok("All facilities", facilityService.getAll()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get facility by ID")
    public ResponseEntity<ApiResponse<Facility>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Facility", facilityService.getById(id)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "[ADMIN] Update facility details")
    public ResponseEntity<ApiResponse<Facility>> update(
            @PathVariable Long id, @Valid @RequestBody FacilityRequest req) {
        return ResponseEntity.ok(ApiResponse.ok("Facility updated", facilityService.updateFacility(id, req)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "[ADMIN] Delete a facility")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        facilityService.deleteFacility(id);
        return ResponseEntity.ok(ApiResponse.ok("Facility deleted", null));
    }

    @PostMapping("/staff")
    @Operation(summary = "[ADMIN] Assign staff to a facility – validates userId via OpenFeign → auth-service")
    public ResponseEntity<ApiResponse<Staff>> createStaff(@Valid @RequestBody CreateStaffRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Staff assigned", facilityService.createStaff(req)));
    }

    @GetMapping("/staff")
    @Operation(summary = "[ADMIN] List all staff")
    public ResponseEntity<ApiResponse<List<Staff>>> getAllStaff() {
        return ResponseEntity.ok(ApiResponse.ok("All staff", facilityService.getAllStaff()));
    }

    @GetMapping("/{id}/staff")
    @Operation(summary = "List staff in a facility")
    public ResponseEntity<ApiResponse<List<Staff>>> getStaffByFacility(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Staff at facility " + id,
                facilityService.getStaffByFacility(id)));
    }

    @GetMapping("/staff/{staffId}")
    @Operation(summary = "Get staff member by ID")
    public ResponseEntity<ApiResponse<Staff>> getStaffById(@PathVariable Long staffId) {
        return ResponseEntity.ok(ApiResponse.ok("Staff", facilityService.getStaffById(staffId)));
    }

    @PatchMapping("/staff/{staffId}/status")
    @Operation(summary = "[ADMIN] Update staff status")
    public ResponseEntity<ApiResponse<Staff>> updateStaffStatus(
            @PathVariable Long staffId, @RequestParam Staff.Status status) {
        return ResponseEntity.ok(ApiResponse.ok("Staff status updated",
                facilityService.updateStaffStatus(staffId, status)));
    }

    /** OpenFeign enrichment: fetch auth-service user details for a staff member */
    @GetMapping("/staff/{staffId}/user")
    @Operation(summary = "Get auth-service user details for staff (via OpenFeign → auth-service)")
    public ResponseEntity<ApiResponse<UserResponse>> getUserForStaff(@PathVariable Long staffId) {
        return ResponseEntity.ok(ApiResponse.ok("User for staff " + staffId,
                facilityService.getUserForStaff(staffId)));
    }
}
