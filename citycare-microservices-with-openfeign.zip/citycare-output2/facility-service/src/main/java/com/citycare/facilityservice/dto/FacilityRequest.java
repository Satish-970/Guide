package com.citycare.facilityservice.dto;

import com.citycare.facilityservice.entity.Facility;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FacilityRequest {
    @NotBlank private String name;
    @NotNull  private Facility.Type type;
    @NotBlank private String location;
    @Min(1)   private int capacity;
    private Facility.Status status;
}
