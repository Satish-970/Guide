package com.citycare.facilityservice.service;

import com.citycare.facilityservice.dto.CreateStaffRequest;
import com.citycare.facilityservice.dto.FacilityRequest;
import com.citycare.facilityservice.entity.Facility;
import com.citycare.facilityservice.entity.Staff;
import com.citycare.facilityservice.exception.ResourceNotFoundException;
import com.citycare.facilityservice.feign.AuthClient;
import com.citycare.facilityservice.feign.dto.UserResponse;
import com.citycare.facilityservice.repository.FacilityRepository;
import com.citycare.facilityservice.repository.StaffRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class FacilityService {

    private final FacilityRepository facilityRepository;
    private final StaffRepository staffRepository;

    // OpenFeign client for cross-service communication
    private final AuthClient authClient;

    // ── Facility ──────────────────────────────────────────────────────────────

    @Transactional
    public Facility createFacility(FacilityRequest req) {
        Facility facility = Facility.builder()
                .name(req.getName())
                .type(req.getType())
                .location(req.getLocation())
                .capacity(req.getCapacity())
                .status(req.getStatus() != null ? req.getStatus() : Facility.Status.ACTIVE)
                .build();
        return facilityRepository.save(facility);
    }

    @Transactional
    public Facility updateFacility(Long id, FacilityRequest req) {
        Facility facility = facilityRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Facility", id));
        facility.setName(req.getName());
        facility.setType(req.getType());
        facility.setLocation(req.getLocation());
        facility.setCapacity(req.getCapacity());
        if (req.getStatus() != null) facility.setStatus(req.getStatus());
        return facilityRepository.save(facility);
    }

    public Facility getById(Long id) {
        return facilityRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Facility", id));
    }

    public List<Facility> getAll() {
        return facilityRepository.findAll();
    }

    @Transactional
    public void deleteFacility(Long id) {
        if (!facilityRepository.existsById(id)) throw new ResourceNotFoundException("Facility", id);
        facilityRepository.deleteById(id);
    }

    // ── Staff ─────────────────────────────────────────────────────────────────

    @Transactional
    public Staff createStaff(CreateStaffRequest req) {
        Facility facility = facilityRepository.findById(req.getFacilityId())
                .orElseThrow(() -> new ResourceNotFoundException("Facility", req.getFacilityId()));

        // Validate that the staff userId exists in auth-service via OpenFeign
        if (req.getUserId() != null) {
            try {
                UserResponse user = authClient.getUserById(req.getUserId());
                log.info("Validated staff user: {} (userId={}, role={})",
                        user.getName(), user.getUserId(), user.getRole());
            } catch (Exception e) {
                log.warn("Could not validate userId={} in auth-service: {}", req.getUserId(), e.getMessage());
            }
        }

        Staff staff = Staff.builder()
                .facility(facility)
                .name(req.getName())
                .role(req.getRole())
                .contactInfo(req.getContactInfo())
                .userId(req.getUserId())
                .status(Staff.Status.ACTIVE)
                .build();
        return staffRepository.save(staff);
    }

    public List<Staff> getStaffByFacility(Long facilityId) {
        if (!facilityRepository.existsById(facilityId))
            throw new ResourceNotFoundException("Facility", facilityId);
        return staffRepository.findByFacilityFacilityId(facilityId);
    }

    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    public Staff getStaffById(Long id) {
        return staffRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Staff", id));
    }

    @Transactional
    public Staff updateStaffStatus(Long id, Staff.Status status) {
        Staff staff = getStaffById(id);
        staff.setStatus(status);
        return staffRepository.save(staff);
    }

    /**
     * Fetch user details from auth-service for a given staff member via OpenFeign.
     */
    public UserResponse getUserForStaff(Long staffId) {
        Staff staff = getStaffById(staffId);
        if (staff.getUserId() == null) return null;
        return authClient.getUserById(staff.getUserId());
    }
}
