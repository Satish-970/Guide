package com.citycare.facilityservice.feign;

import com.citycare.facilityservice.feign.dto.UserResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "auth-service", fallback = AuthClientFallback.class)
public interface AuthClient {

    /**
     * Validate that a userId actually exists in auth-service before creating staff.
     */
    @GetMapping("/api/admin/users/{id}")
    UserResponse getUserById(@PathVariable("id") Long userId);
}
